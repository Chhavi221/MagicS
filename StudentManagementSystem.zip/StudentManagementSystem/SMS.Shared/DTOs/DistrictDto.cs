﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SMS.Shared.DTOs
{
    [Serializable]
    public class DistrictDto
    {
        public int DistrictId { get; set; }
        public string DistrictName { get; set; }
    }
}

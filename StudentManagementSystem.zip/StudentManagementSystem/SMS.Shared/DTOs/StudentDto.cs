﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SMS.Shared.DTOs
{
    [Serializable]
    public class StudentDto
    {
        public int StudentId { get; set; }
        public string FirstName { get; set; }
        public string SecondName { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string Ssn { get; set; }
        public int DistrictId { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SMS.Shared.DTOs
{
    [Serializable]
    public class ServiceDto
    {
        public int ServiceId { get; set; }
        public string ServiceName { get; set; }
        public int SchoolYear { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public int StudentId { get; set; }
    }
}

﻿using Microsoft.EntityFrameworkCore;
using SMS.Data.DataEntities;
using System;
using System.Collections.Generic;
using System.Text;

namespace SMS.Data
{
    public class DataContext : DbContext
    {
        public DataContext(DbContextOptions<DataContext> options) : base(options)
        {

        }

        public virtual DbSet<District> District {get; set;}
        public virtual DbSet<Student> Student { get; set; }
        public virtual DbSet<Enrollment> Enrollment { get; set; }
        public virtual DbSet<Service> Service { get; set; }
    }
}

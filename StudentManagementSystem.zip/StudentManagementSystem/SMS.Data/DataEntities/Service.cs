﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace SMS.Data.DataEntities
{
    public class Service
    {
        [Key]
        public int ServiceId { get; set; }
        [Required]
        public string ServiceName { get; set; }

        [Required]
        public int SchoolYear { get; set; }

        
        public DateTime StartDate { get; set; }

        
        public DateTime EndDate { get; set; }

        [ForeignKey("StudentId")]
        public Student Student { get; set; }
        [Required]
        public int StudentId { get; set; }
    }
}

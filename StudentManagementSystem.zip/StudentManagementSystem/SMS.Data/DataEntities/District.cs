﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SMS.Data.DataEntities
{
    public class District
    {
        public int DistrictId { get; set; }
        public string DistrictName { get; set; }
    }
}

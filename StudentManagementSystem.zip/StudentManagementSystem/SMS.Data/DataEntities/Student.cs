﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace SMS.Data.DataEntities
{
    public class Student
    {
        [Key]
        public int StudentId { get; set; }

        [Required]
        public string FirstName { get; set; }
        public string SecondName { get; set; }
        [Required]
        public DateTime DateOfBirth { get; set; }
        [Required]
        public string Ssn { get; set; }

        [ForeignKey("DistrictId")]
        public District District { get; set; }
        public int DistrictId { get; set; }
    }
}

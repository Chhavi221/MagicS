﻿using AutoMapper;
using SMS.Data.DataEntities;
using SMS.Shared.DTOs;
using System;
using System.Collections.Generic;
using System.Text;

namespace SMS.Data
{
    public class AutoMapperProfile:Profile
    {
        public AutoMapperProfile()
        {
            CreateMap<Student, StudentDto>();
            CreateMap<Service, ServiceDto>();
            CreateMap<District, DistrictDto>();
            CreateMap<Enrollment, EnrollmentDto>();

            CreateMap<StudentDto, Student>();
            CreateMap<ServiceDto, Service>();
            CreateMap<DistrictDto, District>();
            CreateMap<EnrollmentDto, Enrollment>();
        }
    }
}
